#* ************************************************************************** */
#*                                                                            */
#*    main.rb                _             _              :::      ::::::::   */
#*    By: mlu               | |           | |           :+:      :+:    :+:   */
#*     ___  __ _  __ _ _ __ | | __ _ _ __ | |_        +:+ +:+         +:+     */
#*    / _ \/ _` |/ _` | '_ \| |/ _` | '_ \| __|     +/+  +:+       +/+        */
#*   |  __/ (_| | (_| | |_) | | (_| | | | | |_    +/+/+/+/+/+   +/+           */
#*    \___|\__, |\__, | .__/|_|\__,_|_| |_|\__|        /+/    /+/             */
#*          __/ | __/ | |                             ///   ////////.fr       */
#*         |___/ |___/|_|                                                     */
#* ************************************************************************** */

require_relative "player.class"
require_relative "murmillo.class"
require_relative "swordsinger.class"
require_relative "mergen.class"
require_relative "arena.container"

puts "Welcome to arena! This is where you can have multiple people fight!"

game = Arena.new
game.menu
